var searchData=
[
  ['getk',['getK',['../classKmer.html#abba3593449208b49650b204df1b5201c',1,'Kmer']]]
];
