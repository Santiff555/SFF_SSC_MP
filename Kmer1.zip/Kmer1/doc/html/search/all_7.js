var searchData=
[
  ['size',['size',['../classKmer.html#a1bfb58daeb049f2fc31acad74acf8f21',1,'Kmer']]]
];
