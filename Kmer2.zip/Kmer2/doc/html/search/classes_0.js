var searchData=
[
  ['kmer',['Kmer',['../classKmer.html',1,'']]]
];
