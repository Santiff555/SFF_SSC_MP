var searchData=
[
  ['complementary',['complementary',['../classKmer.html#a0ae182d0892b67c8cd96de740550032e',1,'Kmer']]]
];
